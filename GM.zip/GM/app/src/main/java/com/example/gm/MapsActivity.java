package com.example.gm;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    LocationManager locationManager;
    LocationListener listener;
    double lati;
    double lng;
    Marker currentLocationMarker;
//    private FusedLocationProviderClient fusedLocationClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
//        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        listener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {

                LatLng currentLocation = null;
                lati = location.getLatitude();
                lng = location.getLongitude();
                currentLocation = new LatLng(lati, lng);
                if (currentLocationMarker != null) {
                    currentLocationMarker.remove();
                }
                if (lati != 0 && lng != 0) {
                    currentLocationMarker = mMap.addMarker(new MarkerOptions().position(currentLocation).title("You are here!"));
                    currentLocationMarker.showInfoWindow();
                    mMap.moveCamera(CameraUpdateFactory.newLatLng(currentLocation));
                    mMap.animateCamera(CameraUpdateFactory.zoomTo(15));
                }
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {

            }

            @Override
            public void onProviderEnabled(String provider) {


            }

            @Override
            public void onProviderDisabled(String provider) {

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    if(!locationManager.isLocationEnabled())
                    {
                        final AlertDialog.Builder builder= new AlertDialog.Builder(MapsActivity.this);

                        builder.setMessage("Enable GPS").setCancelable(false).setPositiveButton("YES", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                            }
                        }).setNegativeButton("NO", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                dialog.cancel();
                            }
                        });
                        builder.create().show();
                    }
                }
            }
        };
        configurePermission();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case 10:
                configurePermission();
                break;
            default:
                break;
        }
    }

    void configurePermission() {
        // first check for permissions
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.INTERNET}
                        , 10);
            }
            return;
        }
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        locationManager.requestLocationUpdates("gps", 1000*5, 1, listener);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            return;
        }
//        Location locationNetwork = locationManager.getLastKnownLocation(locationManager.NETWORK_PROVIDER);
//        locationManager.requestLocationUpdates("gps", 1000*5, 1, listener);
        Location locationNetwork = locationManager.getLastKnownLocation(locationManager.GPS_PROVIDER);
        mMap.setMyLocationEnabled(true);
        // Add a marker
        LatLng dMart = new LatLng(18.45, 79.12);
        LatLng axisBank = new LatLng(18.43, 79.10);
        LatLng alphores = new LatLng(18.48, 79.10);
        LatLng eenadu = new LatLng(18.39, 79.14);
        LatLng person1 = new LatLng(18.45, 79.99);

        mMap.addMarker(new MarkerOptions().position(dMart).title("D Mart").snippet("Supermarket"));
        mMap.addMarker(new MarkerOptions().position(axisBank).title("Axis bank").icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE)));
        mMap.addMarker(new MarkerOptions().position(alphores).title("Alphores high school"));
        mMap.addMarker(new MarkerOptions().position(person1).title("Anudeep").snippet("9000942213"));
        mMap.addMarker(new MarkerOptions().position(eenadu).title("Eenadu").alpha(0.7f));
//        To focus the specified place
        try {
            currentLocationMarker = mMap.addMarker(new MarkerOptions().position(new LatLng(locationNetwork.getLatitude(),locationNetwork.getLongitude())).title("You are here!"));
            currentLocationMarker.showInfoWindow();
            mMap.moveCamera(CameraUpdateFactory.newLatLng(new LatLng(locationNetwork.getLatitude(),locationNetwork.getLongitude())));
            CameraUpdate zoom = CameraUpdateFactory.zoomTo(15);
            mMap.animateCamera(zoom);

        }
        catch(Exception e)
        {

            mMap.moveCamera(CameraUpdateFactory.newLatLng(new LatLng(17.38,78.48)));
            CameraUpdate zoom = CameraUpdateFactory.zoomTo(4);
            mMap.animateCamera(zoom);
            Log.e("error in catch", e.getMessage()+"1");
        }
    }


}